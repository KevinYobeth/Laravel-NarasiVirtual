<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <title>NARASI: Submission</title>
    <style>
        .container {
            max-width: 500px;
        }

        dl,
        ol,
        ul {
            margin: 0;
            padding: 0;
            list-style: none;
        }

    </style>
</head>

<body>

    <div class="container mt-5">

        <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img src="<?php echo e(url($submission->filePath)); ?>" alt="" width="200px">
            <p>User ID: <?php echo e($submission->userID); ?></p>
            <p>Photo ID: <?php echo e($submission->id); ?></p>
            <p>File Name: <?php echo e($submission->fileName); ?></p>
            <p>Title: <?php echo e($submission->title); ?></p>
            <p>Story: <?php echo e($submission->story); ?></p>
            <p>Aperture: <?php echo e($submission->exifF); ?></p>
            <p>Shutter Speed: <?php echo e($submission->exifSS); ?></p>
            <p>ISO: <?php echo e($submission->exifISO); ?></p>
            <a href="<?php echo e(route('getfile', $submission->fileName)); ?>">
                <button>Download</button></a>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\narasi-virtual\resources\views/submission/view.blade.php ENDPATH**/ ?>