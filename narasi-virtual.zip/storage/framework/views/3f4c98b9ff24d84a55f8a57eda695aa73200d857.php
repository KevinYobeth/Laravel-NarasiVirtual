<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\narasi-virtual\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>