

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php if(session('status')): ?>
        <div class="col-md-8 pb-3">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="row justify-content-center align-items-center">

        <?php if(count($attendedSeminars) > 0): ?>
        <h1 class="montserrat bold col-md-8 text-center">REGISTERED SEMINAR</h1>
        <?php endif; ?>

        <?php $__currentLoopData = $attendedSeminars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendedSeminar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-none d-md-block col-md-12 col-lg-10 py-3">
            <div class="container">
                <img class="img-fluid" src="<?php echo e($attendedSeminar->thumbnail); ?>">
                <div class="bottom-left-join">
                    <a href="<?php echo e($attendedSeminar->link.$uniqueName); ?>">
                        <button type="button" class="btn btn-join">Join Seminar</button>
                    </a>
                </div>

            </div>
        </div>

        <div class="d-md-none col-md-12 col-lg-10 py-3">
            <div class="container">
                <img class="img-fluid" src="<?php echo e($attendedSeminar->thumbnailM); ?>">
                <div class="bottom-center-join">
                    <a href="<?php echo e($attendedSeminar->link.$uniqueName); ?>">
                        <button type="button" class="btn btn-join">Join Seminar</button>
                    </a>
                </div>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(count($seminars) > 0): ?>
        <h1 class="montserrat bold col-md-8 text-center pt-2">AVAILABLE SEMINARS</h1>
        <?php endif; ?>

        <?php $__currentLoopData = $seminars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seminar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-none d-md-block col-md-12 col-lg-10 py-3">
            <div class="container">
                <img class="img-fluid" src="<?php echo e($seminar->thumbnail); ?>">
                <div class="bottom-left">
                    <a href="<?php echo e(route('registerSeminar', ['ID' => $seminar->id])); ?>">
                        <button type="button " class="btn btn-dark">Register</button>
                    </a>
                </div>
            </div>
        </div>

        <div class="d-md-none col-md-12 col-lg-10 py-3">
            <div class="container">
                <img class="img-fluid" src="<?php echo e($seminar->thumbnailM); ?>">
                <div class="bottom-center">
                    <?php if($seminar->id === 2): ?>
                    <a href="<?php echo e(route('registerSeminar', ['ID' => $seminar->id])); ?>">
                        <button type="button " class="btn btn-dark">Buy your ticket</button>
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(route('registerSeminar', ['ID' => $seminar->id])); ?>">
                        <button type="button " class="btn btn-dark">Free Registration</button>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $unverifiedSeminars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seminar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-none d-md-block col-md-12 col-lg-10 py-3">
            <div class="container">
                <img class="img-fluid" src="<?php echo e($seminar->thumbnail); ?>">
                <div class="bottom-left">
                    <button type="button" class="btn btn-dark" data-toggle="tooltip" data-placement="bottom"
                        title="Verification on Process" onclick="alert('Verification on Process')">
                        Verifying
                    </button>
                </div>
            </div>
        </div>

        <div class="d-md-none col-md-12 col-lg-10 py-3">
            <div class="container">
                <img class="img-fluid" src="<?php echo e($seminar->thumbnailM); ?>">
                <div class="bottom-center">
                    <button type="button" class="btn btn-dark" data-toggle="tooltip" data-placement="bottom"
                        title="Verification on Process" onclick="alert('Verification on Process')">
                        Verifying
                    </button>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="col-12 text-center">
            <p>Tip: Don't share your zoom link because it's unique to your user ID! Only 1 user per account will be
                allowed to join.</p>
        </div>
    </div>

</div>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\narasi-virtual\resources\views/dash.blade.php ENDPATH**/ ?>