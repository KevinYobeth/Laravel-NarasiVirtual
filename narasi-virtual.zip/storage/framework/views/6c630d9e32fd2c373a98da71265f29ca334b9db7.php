

<?php $__env->startSection('content'); ?>
<div class="container text-center">

    <h1>Hana Madness</h1>
    <table class="table table-striped">
        <thead class="thead-dark">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Trans ID</th>
                <th scope="col">Name</th>
                <th scope="col">Verified</th>
                <th scope="col">Details</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $hanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hana): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                <td><?php echo e($hana->transactionID); ?></td>
                <td><?php echo e($hana->name); ?></td>
                <td><?php echo e($hana->verified ? "True" : "False"); ?></td>
                <td> <a href="<?php echo e(route('transDetail', ["transID" => $hana->transactionID])); ?>"><button type="button"
                            class="btn btn-info">Info</button></a> </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h1 class="pt-5">Amanda Margareth</h1>

    <table class="table table-striped">
        <thead class="thead-dark">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Trans ID</th>
                <th scope="col">Name</th>
                <th scope="col">Nama Rekening</th>
                <th scope="col">Verified</th>
                <th scope="col">Verify Payment</th>
                <th scope="col">Details</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $amandas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amanda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                <td><?php echo e($amanda->transactionID); ?></td>
                <td><?php echo e($amanda->name); ?></td>
                <td><?php echo e($amanda->namaRekening); ?></td>
                <td><?php echo e($amanda->verified ? "True" : "False"); ?></td>
                <td><a href="<?php echo e(route('verify', ['transID'=> $amanda->transactionID])); ?>" type="button"
                        class="btn btn-success">Verify</a></td>
                <td> <a href="<?php echo e(route('transDetail', ["transID" => $amanda->transactionID])); ?>"><button type="button"
                            class="btn btn-info">Info</button></a> </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\narasi-virtual\resources\views/admin.blade.php ENDPATH**/ ?>