

<?php $__env->startSection('content'); ?>
<div class="container text-center">
    <table class="table table-striped">
        <thead class="thead-dark">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Trans ID</th>
                <th scope="col">Name</th>
                <th scope="col">Nama Rekening</th>
                <th scope="col">Verified</th>
                <th scope="col">Verify Payment</th>
                <th scope="col">Details</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->index + 1); ?></th>
                <td><?php echo e($transaction->transactionID); ?></td>
                <td><?php echo e($transaction->name); ?></td>
                <td><?php echo e($transaction->namaRekening); ?></td>
                <td><?php echo e($transaction->verified ? "True" : "False"); ?></td>
                <td><a href="<?php echo e(route('verify', ['transID'=> $transaction->transactionID])); ?>" type="button"
                        class="btn btn-success">Verify</a></td>
                <td> <a href="<?php echo e(route('transDetail', ["transID" => $transaction->transactionID])); ?>"><button
                            type="button" class="btn btn-info">Info</button></a> </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\narasi-virtual\resources\views/admin.blade.php ENDPATH**/ ?>