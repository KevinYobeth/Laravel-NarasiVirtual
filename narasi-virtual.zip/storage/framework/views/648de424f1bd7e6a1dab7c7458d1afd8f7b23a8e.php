<?php $__env->startComponent('mail::message'); ?>
<center><img src="<?php echo e(asset('img/logo/logo-dark.png')); ?>" width="150"></center>

<?php $__env->startComponent('mail::panel'); ?>
This invoice is PAID & VERIFIED
<?php if (isset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c)): ?>
<?php $component = $__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c; ?>
<?php unset($__componentOriginal78a7183c9f5e577b074162f44312b5a9c6fd7b4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Date: <?php echo e($data['date']); ?> <br>
Method: BCA Transfer <br>
Issued To: <?php echo e($data['name']); ?> <br>

## Invoice Number: <?php echo e($data['invoiceNum']); ?> <br>

# Transaction Summary:

<?php $__env->startComponent('mail::table'); ?>
| Item | Price |
|:---------------------------------------|----------:|
| Seminar: How To take Expressive Photos | Rp35.000 |
| Knowledge :D | Rp0 |
| Pop Corn Virtual | Rp0 |
| **TOTAL** | Rp35.000 |
<?php if (isset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906)): ?>
<?php $component = $__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906; ?>
<?php unset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::button', ['url' => $data['invoiceURL']]); ?>
View this form online
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\narasi-virtual\resources\views/mails/invoice.blade.php ENDPATH**/ ?>