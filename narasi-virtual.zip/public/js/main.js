// let sunibian = document.querySelector('input[name="radBinusian"]:checked').value;
