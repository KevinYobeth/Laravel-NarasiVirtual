@extends('layouts.app')

@section('content')

<body>

    <div class="container mt-5">
        <form action="{{ route('uploadSubmission') }}" method="post" enctype="multipart/form-data">
            <h3 class="text-center mb-5">Upload Photo Submission</h3>
            @csrf
            @if($message = Session::get('success'))
                <div class="alert alert-success">
                    <strong>{{ $message }}</strong>
                </div>
            @endif

            @if(count($errors) > 0)
                <div class="alert alert-danger">
                    <ul>
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="custom-file">
                <input type="file" name="file" class="custom-file-input" id="chooseFile">
                <label class="custom-file-label" for="chooseFile">Select file</label>
            </div>

            <br>
            <label for="title">Title</label>
            <br>
            <input class="form-control" type="text" name="title">

            <label for="story">Story</label>
            <br>
            <input class="form-control" type="text" name="story">

            <button type="submit" name="submit" class="btn btn-primary btn-block mt-4">
                Upload Files
            </button>
        </form>
    </div>

</body>

</html>

@endsection
