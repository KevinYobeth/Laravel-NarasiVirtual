<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Motd extends Model
{
    protected $table = 'motds';
}
