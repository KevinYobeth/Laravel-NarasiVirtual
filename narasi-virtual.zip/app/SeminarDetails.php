<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SeminarDetails extends Model
{
    protected $table = 'seminar_details';
}
